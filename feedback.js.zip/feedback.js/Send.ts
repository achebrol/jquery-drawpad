export class Send {
  constructor() {}
  send(data: any, callback: Function) {}
}
